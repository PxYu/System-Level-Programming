/****************************************************************************************
 * Copyright (c) 1999-2001 Microsoft Corporation.  All Rights Reserved.
 *
 * File:
 *  profilerGCP.cpp
 *
 * Description:
 *	
 *
 *
 ***************************************************************************************/
#include "prf_common.h"
#include "avlnode.hpp"
#include "basehlp.hpp"

#include "ProfilerInfo.cpp"
#include "ProfilerCallback.cpp"

// End of File

